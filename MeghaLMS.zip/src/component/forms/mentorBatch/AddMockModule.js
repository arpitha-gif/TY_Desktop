import React from "react";

function AddMockModule() {
  return (
    <div>
      <ModuleComponent />
    </div>
  );
}

export default AddMockModule;
