import React from "react";

function MentorDashboard() {
  return <div>MentorDashboard</div>;
}

export default MentorDashboard;
