const ADMIN_MENTOR_HEADER = [
  {
    id: "col1",
    nummeric: false,
    disablePadding: false,
    label: "No.",
    width: 70,
  },
  {
    id: "col2",
    nummeric: false,
    disablePadding: false,
    label: "Mentor Name",
    width: 150,
  },
  {
    id: "col3",
    nummeric: false,
    disablePadding: false,
    label: "Employee ID",
    // filter: "select",
    width: 130,
  },
  {
    id: "col4",
    nummeric: false,
    disablePadding: false,
    label: "E-mail ID",
    width: 230,
  },
  {
    id: "col5",
    nummeric: false,
    disablePadding: false,
    label: "Skills",
    // filter: "select",
    width: 400,
  },
  //   {
  //     id: "col6",
  //     nummeric: false,
  //     disablePadding: false,
  //     label: "Start Date",
  //     width: 100,
  //   },
  //   {
  //     id: "col7",
  //     nummeric: false,
  //     disablePadding: false,
  //     label: "Start Date",
  //     sort: false,
  //     width: 100,
  //   },
  //   {
  //     id: "col8",
  //     nummeric: false,
  //     disablePadding: false,
  //     label: "Status",
  //     sort: false,
  //     width: 100,
  //   },
];

export default ADMIN_MENTOR_HEADER;
