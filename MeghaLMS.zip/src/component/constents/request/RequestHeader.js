const REQUEST_HEADER = [
  {
    id: "col1",
    nummeric: false,
    disablePadding: false,
    label: "No.",
    width: 80,
  },
  {
    id: "col2",
    nummeric: false,
    disablePadding: false,
    label: "Employee ID",
    width: 120,
  },
  {
    id: "col3",
    nummeric: false,
    disablePadding: false,
    label: "Employee Name",
    // filter: "select",
    width: 120,
  },
  {
    id: "col4",
    nummeric: false,
    disablePadding: false,
    label: "YOP",
    width: 100,
  },
  {
    id: "col5",
    nummeric: false,
    disablePadding: false,
    label: "Percentage",
    // filter: "select",
    width: 120,
  },
  {
    id: "col6",
    nummeric: false,
    disablePadding: false,
    label: "Experience",
    width: 120,
  },
  {
    id: "col7",
    nummeric: false,
    disablePadding: false,
    label: "Contact No.",
    sort: false,
    width: 100,
  },
];

export default REQUEST_HEADER;
