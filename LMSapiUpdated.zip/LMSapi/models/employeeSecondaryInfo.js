const mongoose = require('mongoose')

const empSecondarySchema= new mongoose.Schema({
    
})

module.exports = mongoose.model('employeeSecondaryinfo',empSecondarySchema)