const mongoose = require('mongoose')

const empBankDetailsSchema = new mongoose.Schema({
    
})

module.exports = mongoose.model('employeeBankDetails',empBankDetailsSchema)